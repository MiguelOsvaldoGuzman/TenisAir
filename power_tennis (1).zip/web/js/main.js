function clickBottom(id){
  window.alert ("click "+id);
}
